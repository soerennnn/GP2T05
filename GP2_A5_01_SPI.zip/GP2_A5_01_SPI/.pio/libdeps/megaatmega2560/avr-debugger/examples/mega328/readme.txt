Examples for ATmega328 MCU (Arduino Uno and other varians with this MCU).

To upload to the board use this avrdude programmer configuration:
Arduino Uno - Programmer hardware: Arduino, baudrate 115200
 
