/*
 * LIS3DH.c
 *
 * Created: 14.05.2018 13:49:24
 *  Author: Kroll
 */ 
//#define F_CPU 16000000UL

#include <avr/io.h>	 
#include "LIS3DH.h"
#include "../SPI/SPI.h"
#include <util/delay.h>


/************************************************************************/
/*				           LIS3DH REG DEF					            */
/************************************************************************/

#define WHO_AM_I	0x0F

#define OUT_X_L		0x28
#define OUT_X_H		0x29
#define OUT_Y_L		0x2A
#define OUT_Y_H		0x2B
#define OUT_Z_L		0x2C
#define OUT_Z_H		0x2D

#define CTRL_REG1	0x20
#define CTRL_REG2	0x21
#define CTRL_REG3	0x22
#define CTRL_REG4	0x23
#define CTRL_REG5	0x24
#define CTRL_REG6	0x25

/* CTRL_REG1 Parameter */
#define Xen			0x00
#define Yen			0x01
#define Zen			0x02
#define LPen		0x03

/************************************************************************/
/*				           LS3DH FUNCTIONS	                            */
/************************************************************************/

char SPI_LIS3DH_INIT(void)
{
	char dataRcv =0;
	PORTB &= ~(1 << PB0);			// CHIPSELECT LOW --> BEGIN SPI
	
	SPI_MasterTransmit(WHO_AM_I | 0x80);
	dataRcv = SPI_MasterReceive();
	
	
	PORTB |= (1 << PB0);
	_delay_ms(50);
	
	// HR / Normal / Low-power mode (400 Hz)
	// enable XYZ axis
	PORTB &= ~(1 << PB0);
	SPI_MasterTransmit(CTRL_REG1);
	SPI_MasterTransmit(0x77);
	PORTB |= (1 << PB0);
	
	_delay_ms(50);
	PORTB &= ~(1 << PB0);
	// no Highpassfiltering
	SPI_MasterTransmit(CTRL_REG2);
	SPI_MasterTransmit(0x00);
	PORTB |= (1 << PB0);
	
	_delay_ms(50);
	PORTB &= ~(1 << PB0);
	// no interrupt enable
	SPI_MasterTransmit(CTRL_REG3);
	SPI_MasterTransmit(0x00);
	
	PORTB |= (1 << PB0);
	_delay_ms(50);
	PORTB &= ~(1 << PB0);
	// Block Data update + High resolution mode on
	SPI_MasterTransmit(CTRL_REG4);
	SPI_MasterTransmit(0x88);
	PORTB |= (1 << PB0);
	
	_delay_ms(50);
	
	
	return dataRcv;
	
}
